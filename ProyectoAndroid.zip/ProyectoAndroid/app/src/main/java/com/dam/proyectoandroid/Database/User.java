package com.dam.proyectoandroid.Database;

import java.io.Serializable;

public class User implements Serializable {
    public String name;
    public String email;
    public String password;
}